import TooltipElement from './TooltipElement';

export default TooltipElement;