export const API_BASE_URL = "https://eleveight-api.azurewebsites.net/api/";
export const OrginUrl=window.location.origin;
